# Q17-PSU-MONO version 1.0<br>

Universal mono bridge Power Supply for Class B amplifiers.

Version 1.0 published on April 15, 2024.

<a href="https://audio.cyberkata.org/Q17-PSU-MONO-BOM.html">Online Q17-PSU-MONO-BOM</a><br>

![Q17-PSU-MONO-3D-VIEW](https://github.com/stefaweb/Q17-Amplifier/assets/12907102/3fa3c49f-a85b-4dcf-bc45-1494a5ed3b3b)

![Q17-PSU-MONO-SCHEMATIC](https://github.com/stefaweb/Q17-Amplifier/assets/12907102/8f68d0ad-1442-482f-bb70-c21a93aa6339)

![Q17-PSU-MONO-3D-TOP](https://github.com/stefaweb/Q17-Amplifier/assets/12907102/6baf6d50-7ec1-4b70-a1ef-c736e2bee90b)

![Q17-PSU-MONO-PCB-FRONT](https://github.com/stefaweb/Q17-Amplifier/assets/12907102/429916b5-63d1-43b6-8e09-caf8368283de)

![Q17-PSU-MONO-PCB-BACK](https://github.com/stefaweb/Q17-Amplifier/assets/12907102/9c700dda-28e2-414d-9f28-eae2750ae2c1)




