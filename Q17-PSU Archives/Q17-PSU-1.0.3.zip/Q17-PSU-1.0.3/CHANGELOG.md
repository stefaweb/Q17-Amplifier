# Changelog Q17-PSU

Version [1.0.3] (30-08-2023)

- Changed C1 and C2 for 10nF 100V COG (do not use MKP here with Saligny bridge).
- Updated schematic with available Mouser part number and datasheet links.
- Updated PCB for new C1 and C2 footprint (pitch of 5mm).
- Updated BOM.
