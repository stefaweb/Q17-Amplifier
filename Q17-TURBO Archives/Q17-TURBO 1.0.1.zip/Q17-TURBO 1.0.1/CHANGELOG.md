# Changelog Q17-Turbo

Version [1.0.1](https://github.com/stefaweb/Q17-a-QUAD405-audiophile-approach/tree/5d390576078fdaf95bd449d5fe2e2c45a9edb5e6) (9-05-2023)

- Added U2 footprint on back PCB (NDC7003P can replace Q9 and Q11).
- Updated some silkscreen on back PCB.
- Updated schematic with new parts.

Initial release : [1.0.0](https://github.com/stefaweb/Q17-a-QUAD405-audiophile-approach/blob/main/Q17-TURBO%20Archives/Q17-TURBO%201.0.zip) (10-12-2021)
