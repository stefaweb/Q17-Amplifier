# Components for Q17-Turbo SMD version

Do not use U1 and Q7 on the front PCB.

Instead use the following components on the back PCB:

U1' : OPA1611AIDR
Q7' : JFE150DBVR
