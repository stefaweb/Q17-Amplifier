# Modèles DIY IXTQ50N20P / IXTQ26P20P - révision 2

Date : 31 octobre 2026. Simulation : Q17-Mini LTSpice 3.1.2.

Les deux modèles actifs et leurs symboles ont été renommés `_DIY`. Le schéma utilise maintenant ces modèles. Les autres composants, les résistances et les réglages de simulation sont conservés. Les anciens modèles sont dans `DIY_Previous` sous le nom `_DIY_R1`.

## Méthode

Les points ont été extraits des tracés vectoriels des PDF fournis, puis contrôlés sur les pages rendues. Ce sont des courbes typiques imprimées, pas des mesures individuelles ni une identification unique du composant.

- Canal MOS niveau 3 : ajustement conjoint des courbes de transfert (figure 7) et de transconductance (figure 8), avec priorité aux courants de quelques ampères. Les paramètres effectifs VTO, KP et THETA varient avec la température, par interpolation des courbes -40/25/150 °C pour N et -40/25/125 °C pour P. Au-delà, ces paramètres sont plafonnés aux températures des courbes.
- Résistance série : cible typique approximative lue sur la figure 1, environ 50 mΩ pour N et 115 mΩ pour P à 25 °C. Ce ne sont pas les maxima garantis de 60 et 170 mΩ. La variation est estimée depuis la figure 4.
- Capacités : Cgd=Crss, Cds=Coss-Crss, Cgs=Ciss-Crss. Les fonctions de charge Q(V) intègrent des capacités linéaires par morceaux ; elles évitent d'utiliser simplement C(V)*V, dont la dérivée ne serait pas C(V). Les points à 25 V sont calés sur le tableau. La forme mesurée de Crss/Coss est utilisée jusqu'à 40 V ; extrapolation en 1/sqrt(V) au-delà.
- Diode de corps : loi effective ajustée à la figure 9 à 25 °C, avec résistance série. La fuite inverse est limitée séparément pour ne pas transformer le paramètre effectif de courant de saturation en fuite irréaliste. Une charge de diffusion approximative utilise Qrr/IF (80 ns N ; 169 ns P), sans prétendre reproduire exactement trr.
- Rg interne conserve l'hypothèse de 1 Ω ; les résistances externes du montage de mesure ne sont pas prises pour des résistances internes.

Le guide Littelfuse Rev 24.03a sert aux définitions et conditions de mesure ; les nombres de son transistor d'exemple IXTH120N20X4 ne sont pas transférés à cette paire.

## Vérification LTspice 26.0.2 pour macOS

| Contrôle | IXTQ50N20P_DIY | IXTQ26P20P_DIY |
|---|---:|---:|
| Erreur RMS Id sur les points de transfert à 25 °C, 0,5 < Id < 40 A | 0.43 A | 1.64 A |
| Même contrôle avec l'ancien modèle | 37.33 A | 16.67 A |
| Abs(Vgs) à 3,125 A, abs(Vds)=10 V | 5.948 V | 4.466 V |
| Ron à 25 °C, Vgs=+/-10 V, Id=25 A / 13 A | 51.1 mΩ | 114.1 mΩ |
| Qg simulée jusqu'à abs(Vgs)=10 V | 67.9 nC | 56.0 nC |
| Qg typique du tableau | 70 nC | 56 nC |
| Abs(Vsd), diode à 50 A / 13 A | 1.007 V | 2.512 V |
| Abs(Vgs) lorsque abs(Vds)=50 V dans le test de charge | 7.35 V | 5.39 V |

Les tests de charge utilisent les courants du datasheet (N : 25 A / 10 mA de grille ; P : 13 A / 1 mA de grille), avec limitation du drain à environ 100 V. C'est une comparaison approchée, pas une reproduction du banc constructeur. Un accord de Qg totale ne garantit pas l'accord de tout le plateau Miller. Pour N, le niveau du plateau reste notamment plus haut que celui de la figure 10 ; aucun ajustement artificiel du canal n'a été fait pour masquer ce désaccord.

À 25 V / 1 MHz, les valeurs natives obtenues sont proches de Ciss/Coss/Crss = 2720/490/105 pF (N), 2740/540/100 pF (P). Les valeurs et autres tensions sont dans le CSV joint. Cgs est tenu constant : toute la variation de Ciss n'est donc pas reproduite.

Le transitoire Q17 d'origine (30 ms, données sauvegardées 20-30 ms) s'est terminé : sortie 2.828733 Vrms et 1.000216 W sous 8 Ω, sans retoucher l'entrée. THD calculée par la commande `.four` conservée : 0.071611 %. Cette valeur n'est ni une mesure QA403, ni une validation de la distorsion réelle.

## Limites importantes

- Le seuil de la fiche est défini à 250 µA. L'ajustement privilégie la zone ampère : VTO est un paramètre effectif (environ 5,28 V N / 3,62 V P), pas une reproduction du seuil garanti. La faible inversion et les courants sous 0,5 A ne sont pas identifiés par ces tracés. Éviter de déduire une THD de croisement précise de ces modèles.
- Le gfs typique tabulé et la dérivée des courbes ne coïncident pas exactement. La révision est un compromis fondé sur les courbes, pas un ajustement exact de tous les nombres de la fiche.
- La diode effective reste à sa caractéristique 25 °C lorsque `.temp` change. Sa température, la forme de récupération inverse et trr ne sont pas calibrés. Le Ron et le canal ont, eux, une dépendance en température approximative.
- Pas de modèle thermique auto-couplé, de SOA, de limite de courant, de destruction ou d'énergie d'avalanche. Le blocage/claquage à 200 V n'est pas identifié. Ne pas utiliser pour calculer une protection ou une marge d'avalanche.
- Pas de modèle de bruit calibré : pas de prédiction fiable du SNR. Pas d'ajustement sur les mesures audio de C7 ; la distorsion réelle et la stabilité doivent être contrôlées au banc.

## Sources fournies

- Littelfuse Discrete MOSFETs IXT_50N20P Datasheet.pdf : DS99156F(07/08), tableaux pages 1-2, figures 1/4 page 3, figures 7-11 page 4.
- Littelfuse-Discrete-MOSFETs-P-Channel-IXT-26P20P-Datasheet.PDF : DS99913D(01/13), tableaux pages 1-2, figures 1/4 page 4, figures 7-11 page 5.
- Littelfuse-Discrete-Power-MOSFET-Datasheet-Explanation-EN-Application-Note.pdf : Rev 24.03a, définitions pages 9-14 et interprétation des courbes pages 16-20.

Les fichiers dans `DIY_Validation` permettent de reproduire les contrôles. Les coordonnées extraites et les résultats sont conservés séparément ; ils ne constituent pas une certification constructeur.
