# Q17-Mini version 1.3 (100W @ 8 Ohms)<br>

THD: 0.018%<br>
THD+N: 0.09%<br>
DC offset at output: 0.02v<br>
Power supply: 45-50vDC<br>
Idle consumption: 12W @ 240v<br>

The first version of the board was released on December 8, 2021.

Version 1.3 published on August 28, 2022.

Read the CHANGELOG file to know what's new.

<a href="https://audio.cyberkata.org/Q17-Mini-BOM.html">Q17-Mini-BOM Online Version</a><br>
<br>

![IMG_7119](https://user-images.githubusercontent.com/12907102/186949009-f9dca25a-3b77-4e79-b817-db886164d045.jpeg)

![IMG_7121](https://user-images.githubusercontent.com/12907102/186954204-37dbab7d-af63-4a9b-8544-0cef246c1225.jpeg)

![Q17-Mini-1 3_spectrum](https://user-images.githubusercontent.com/12907102/189294781-cff1cc9a-bd83-4b75-bac8-acc55bfa9ec6.jpg)

![stepped_sin](https://user-images.githubusercontent.com/12907102/190194852-40d42843-2d08-4dd0-b583-4583f5c79af1.jpg)

![Q17-Mini-schematic](https://github.com/stefaweb/Q17-a-QUAD405-audiophile-approach/assets/12907102/33f56e95-8f87-4370-997f-09916512c885)

![Q17-Mini-3D](https://user-images.githubusercontent.com/12907102/186886996-d3bc09cb-5950-43d9-befd-7f4f50fa0994.jpg)

![Q17-Mini-3D-FRONT](https://user-images.githubusercontent.com/12907102/186886993-d289c6fd-c93c-481c-8652-cafee727dd6e.jpg)

![Q17-Mini-3D-BACK](https://user-images.githubusercontent.com/12907102/186886986-c2cd2426-bd82-4aa9-8164-c0ce81b99343.jpg)

![Q17-Mini-PCB](https://user-images.githubusercontent.com/12907102/186887015-b0b0a7d2-3b07-41a8-adbc-ce6164e2dc82.jpg)

95x75mm 2 Oz PCB

![Q17-1 3-PCB-scan](https://user-images.githubusercontent.com/12907102/186886981-c5b678a8-5ec7-4ca9-a90e-ef85f9a3f41b.jpg)

![Q17-Mini-drilling](https://user-images.githubusercontent.com/12907102/187089535-22ca085d-42d1-407b-aade-f6f342333dc8.jpg)


